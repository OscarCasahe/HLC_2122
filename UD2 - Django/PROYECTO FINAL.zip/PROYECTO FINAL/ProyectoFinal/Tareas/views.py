from django.http.response import HttpResponse


def prueba_tareas(request):
    return HttpResponse("Esta la página de Tareas")
